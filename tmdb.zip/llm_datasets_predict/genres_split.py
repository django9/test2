import pandas as pd

# 载入元数据文件，并筛选 genres 字段列
keywords_df = pd.read_csv("../datasets/raw/movies_metadata.csv", sep=",", low_memory=False)
keywords_df = keywords_df[["id", "genres"]]

new_keywords = []
for _, row in keywords_df.iterrows():
    keywords_row_list = eval(row["genres"])
    if isinstance(keywords_row_list, list):
        keywords_lists = []
        for keyword_row in keywords_row_list:
            keywords_lists.append(keyword_row["name"])
        if keywords_lists:
            keywords_str = "|".join(keywords_lists)
        else:
            keywords_str = " "
        new_keywords.append({"movieId": row["id"], "genres": keywords_str})
new_keywords_df = pd.DataFrame(new_keywords)
new_keywords_df.to_csv("../datasets/llm_pre/out_genres_list.csv", sep=",", encoding="utf-8", index=False)
