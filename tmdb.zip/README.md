## tools 工具类

**database.py：** Neo4j请求工具类，将Neo4j请求转化为JSON数据返回

## neo4j_datasets_preprocess 导入知识图谱前预处理

**credits_pre.py：** cast表和crew表预处理

**keywords_pre.py：** 关键词预处理

**title_pre.py.py：** id对应电影标题预处理

**datasets_pre.py：** 其余元数据预处理

## llm_datasets_preprocess 大模型数据预处理

**data_sampling.py：** 数据抽样预处理

**genres_split.py：** 电影类型分割预处理

**keyword_split.py：** 电影关键词分割预处理

**score.py：** 评分标准计算

## datasets 数据集

## agent LangChain Agent大模型交换相关
**fine_tuning_datasets_generating.py, tuning_data_formatting.py：** 大模型微调语料生成

**zero_tuning_datasets_generating.py：** Neo4j知识图谱数据 未微调大模型评分预测

**zero_tuning_datasets_withgenres_generating.py：** 电影类型 未微调大模型评分预测

**zero_tuning_datasets_withkeywords_generating.py：** 关键词数据 未微调大模型评分预测

##参考

### transformer微调LLM详细教程.ipynb

后面可以以该文件作为参考，以其他方式计算大模型微调时的loss，自动化选择或剔除一定的语料，
提高大模型的训练效率

## cypher_database_tool.py

该代码是通过大模型来获取具体需要的Neo4j Cypher代码，通过大模型输出的Cypher代码输入到Neo4j知识图谱，
知识图谱的数据再重新返回至大模型中

## 相关文档

langchain官方文档：https://www.langchain.com/

langchain中文文档：https://www.langchain.com.cn/getting_started/getting_started

LLaMA-Factory微调平台：https://github.com/hiyouga/LLaMA-Factory

Xinference推理平台：https://inference.readthedocs.io/zh-cn/latest/index.html