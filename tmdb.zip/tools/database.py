from neo4j import GraphDatabase
import json


class Neo4jDatabase:
    def __init__(self, host: str = "neo4j://localhost:7687",
                 user: str = "neo4j",
                 password: str = "password"):
        # 初始化neo4j driver
        self.host = host
        self.driver = GraphDatabase.driver(host, auth=(user, password))

    def query(
            self,
            cypher_query: str,
            core_node: str,
            params=None
            , record=None):
        # neo4j cypher语句请求
        # core_node 指输出时的中心节点
        if params is None:
            params = {}
        # print(f"在 {self.host} 执行Cypher查询：\n{cypher_query}")
        with self.driver.session() as session:
            result = session.run(cypher_query, params).single()

            # print(result.data())
            # return [r.data() for r in result]
            # results = []
            # for record in result:
            #     movie = record["m"].properties
            #     relationships = record["relationships"]
            #     results.append({"movie": movie, "relationships": relationships})
            # return results
            # return result.data()
            # for record in result["Result"]["Relationship"]:
            #     print(dict(record))
            # try:
            # for record in result["Result"]["Relationship"]:
            #     formatted_result = {
            #         core_node: dict(result["Result"][core_node]),
            #         # "Relationships": [
            #         #     {"Node": dict(record["Node"]), "Relationship": record["Relationship"].type}
            #         #     for record in result["Result"]["Relationship"]
            #         # ]
            #         record["Relationship"].type: dict(record["Node"])
            #     }

            # neo4j 请求数据 打包为 结构体 并返回
            formatted_result = {
                core_node: dict(result["Result"][core_node]),
                **{relationship_type: [] for relationship_type in
                   set([r["Relationship"].type for r in result["Result"]["Relationship"]])},
            }
            for record in result["Result"]["Relationship"]:
                relationship_type = record["Relationship"].type
                formatted_result[relationship_type].append(dict(record["Node"]))
            return json.dumps(formatted_result)
            # except:
            #     return result.data()


if __name__ == "__main__":
    # 测试用
    database = Neo4jDatabase(host="bolt://127.0.0.1:7687",
                             user="neo4j", password="password")

    # b = database.query("""
    # MATCH (n) RETURN {count: count(*)} AS count
    # """)
    data_test = database.query(
        """
    MATCH (m:Movie {title: "Toy Story"})
    WITH m
    OPTIONAL MATCH p=(n)-[r]-(m) 
    WITH m, COLLECT({Node: n, Relationship: r}) AS relationship
    RETURN {
      Movie: m,
      Relationship: relationship
    } AS Result
    """,
        core_node="Movie"
    )
    print(data_test)
