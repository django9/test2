import json
import pandas as pd
from langchain.chat_models import ChatOpenAI
from langchain import PromptTemplate, LLMChain
from langchain import PromptTemplate, FewShotPromptTemplate
from langchain.schema import AIMessage, HumanMessage, SystemMessage
from langchain.memory import ConversationBufferMemory, ReadOnlySharedMemory

# 定义随机数种子
random_state = 42

# 输出文件路径
csv_file = f"../datasets/result/number/test_set_instruction_1k.csv"

# 数据集载入
train_df = pd.read_csv(f"../datasets/llm_pre/train_set_{random_state}_1k.csv", sep=",", low_memory=False)
train_df = train_df[["userId", "movieId", "rating"]]
test_df = pd.read_csv(f"../datasets/llm_pre/test_set_{random_state}_1k.csv", sep=",", low_memory=False)
test_df = test_df[["userId", "movieId", "rating"]]
# keywords_df = pd.read_csv("../datasets/llm_pre/keywords.csv", sep=",", low_memory=False)
# keywords_df = keywords_df[["movieId", "keywords"]]

# Neo4j元数据载入
metadata_df = pd.read_csv("../datasets/llm_pre/id_neo4j_merge.csv", sep=",", low_memory=False)
# metadata_df['neo4j_context'] = metadata_df['neo4j_context'].str.replace("{", "{{")
# metadata_df['neo4j_context'] = metadata_df['neo4j_context'].str.replace("}", "}}")

# 数据集 与 元数据 left join
train_df = pd.merge(train_df, metadata_df, left_on='movieId', right_on='movieId', how='left')
test_df = pd.merge(test_df, metadata_df, left_on='movieId', right_on='movieId', how='left')

# System Prompt
system_prompt = """Based on the user's past rating history and movie's metadata
You're required to predict user ratings for the candidate movie.
The rating ranges from 0 to 5 with increments of 0.5 allowed.
Please provide a single NUMBER as rating WITHOUT saying anything else. Do not give reasoning."""

# 定义输入提示模板
movie_template = "{title}:{rating}\n{neo4j_context}"
example_prompt = PromptTemplate(
    input_variables=["title", "rating", "neo4j_context"],
    template=movie_template,
)
prefix = "The user history are:"

train_prompt = []
response_list = []

# 定义函数以处理Neo4j上下文的JSON数据
def neo4j_context_json_trun(row: str):
    neo4j_context_json = json.loads(row)

    # 处理不同类型的元数据并进行格式转换
    if 'HAS_GENRE' in neo4j_context_json:
        genre_list = [item['genre'] for item in neo4j_context_json['HAS_GENRE']]
        neo4j_context_json['genres'] = genre_list
        del neo4j_context_json["HAS_GENRE"]

    if 'HAS_KEYWORD' in neo4j_context_json:
        keyword_list = [item['keyword'] for item in neo4j_context_json['HAS_KEYWORD']]
        neo4j_context_json['keywords'] = keyword_list
        del neo4j_context_json["HAS_KEYWORD"]

    if 'original_language' in neo4j_context_json:
        original_language_list = [item['original_language'] for item in neo4j_context_json['original_language']]
        neo4j_context_json['original_language'] = original_language_list

    if 'PRODUCTED_IN' in neo4j_context_json:
        producted_in_list = []
        for item in neo4j_context_json['PRODUCTED_IN']:
            producted_in_list.append({item['job']: item['name']})
        neo4j_context_json['producers'] = producted_in_list
        del neo4j_context_json["PRODUCTED_IN"]

    if 'product' in neo4j_context_json:
        product_list = [item['name'] for item in neo4j_context_json['product']]
        neo4j_context_json['product_companies'] = product_list
        del neo4j_context_json["product"]

    if 'ACTED_IN' in neo4j_context_json:
        acted_in_list = [item['name'] for item in neo4j_context_json['ACTED_IN']]
        neo4j_context_json['actors'] = acted_in_list
        del neo4j_context_json["ACTED_IN"]

    if 'product_countries' in neo4j_context_json:
        product_countries_list = [item['name'] for item in neo4j_context_json['product_countries']]
        neo4j_context_json['product_countries'] = product_countries_list

    # 删除其余字段
    del neo4j_context_json["Movie"]["overview"]
    del neo4j_context_json["Movie"]["popularity"]
    del neo4j_context_json["Movie"]["vote_average"]
    del neo4j_context_json["Movie"]["vote_count"]
    del neo4j_context_json["Movie"]["revenue"]
    del neo4j_context_json["Movie"]["id"]

    # 转换为字符串并处理花括号
    neo4j_context_json = json.dumps(neo4j_context_json).replace("{", "{{").replace("}", "}}")
    return neo4j_context_json


# 初始化最大长度和对应用户ID的变量
i = 0
max_len = 0
max_len_userid = 0

# 遍历每个用户
for userId in train_df["userId"].unique():
    i += 1
    # 用于测试特定用户时使用
    # if userId != 39426:
    #     continue

    user_df = train_df[train_df["userId"] == userId]
    user_records = user_df[["title", "rating", "neo4j_context"]].to_dict(orient='records')
    user_test_df = test_df[test_df["userId"] == userId]
    test_records = user_test_df[["title", "movieId", "rating", "neo4j_context"]].to_dict(orient='records')
    test_movieId = test_records[0]["movieId"]

    # 处理每个用户记录中的Neo4j上下文
    for row in user_records:
        neo4j_context_json = neo4j_context_json_trun(row["neo4j_context"])
        row["neo4j_context"] = neo4j_context_json

    # 创建少样本提示模板
    pre_example_prompt = FewShotPromptTemplate(
        examples=user_records,
        example_prompt=example_prompt,
        example_separator="\n",
        prefix=prefix,
        suffix="\n\n候选电影是\"{movie}\"。\n{movie_context}",
        input_variables=["movie", "movie_context"],
    )

    # 格式化完整的提示
    full_prompt = pre_example_prompt.format(
        movie=test_records[0]["title"],
        movie_context=neo4j_context_json_trun(test_records[0]["neo4j_context"]),
    )

    # 记录最长的提示及其对应的用户ID
    if len(full_prompt) > max_len:
        max_len = len(full_prompt)
        max_len_userid = userId

    try:
        response = test_records[0]["rating"]
        row = {"UserId": userId, "movieId": test_movieId, "input": str(repr(full_prompt)), "response": str(response)}
        print(response)
    except:
        row = {"UserId": userId, "movieId": test_movieId, "input": "NULL", "response": "NULL"}

    print(userId)

    row_df = pd.DataFrame(row, index=[i])

    # 将结果追加写入CSV文件
    with open(csv_file, 'a', encoding="utf-8") as f:
        row_df.to_csv(f, header=f.tell() == 0, index=False, mode='a')

# 打印最长的提示及其对应的用户ID
print(max_len, max_len_userid)
