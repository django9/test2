import pandas as pd
import json
import re


def save_json(save_path, data):
    assert save_path.split('.')[-1] == 'json'
    with open(save_path, 'w') as file:
        json.dump(data, file, indent=2)
    with open(save_path, 'r') as file:
        print(type(json.load(file)))

# random_state = 42
# llm_model_size = "72b"
# model = f"qwen1.5_{llm_model_size}"
# model = "gpt-3.5-turbo-0125"

df = pd.read_csv(f"../datasets/result/number/test_set_instruction_1k.csv", sep=",", low_memory=False)

system_prompt = """Based on the user's past rating history and movie's metadata
You're required to predict user ratings for the candidate movie.
The rating ranges from 0 to 5 with increments of 0.5 allowed.
Please provide a single NUMBER as rating WITHOUT saying anything else. Do not give reasoning."""

data = []
# pattern = re.compile(r"\\nIt\\'s Rating:\d+\.\d+\.", re.DOTALL)
for _, row in df.iterrows():
    input = row["input"][1:-1]
    # input = re.sub(pattern, '', input)
    input = input.replace("{{", "{").replace("}}", "}")
    print(input)
    output = str(row["response"])
    messages = {
        "instruction": system_prompt,
        "input": input,
        "output": output,
    }
    data.append(messages)
    # print(data)
# out_json = json.dumps(data)
save_json(f"../datasets/result/number/rating_predict_tuning_datasets_1k.json", data)
