import json
import time
from openai import OpenAI

import pandas as pd
from langchain.chat_models import ChatOpenAI
from langchain import PromptTemplate, LLMChain
from langchain import PromptTemplate, FewShotPromptTemplate
from langchain.schema import AIMessage, HumanMessage, SystemMessage
from langchain.memory import ConversationBufferMemory, ReadOnlySharedMemory

random_state = 6
llm_model_size = "4b"
model = f"Qwen/Qwen1.5-{llm_model_size}-Chat"
# model = "Qwen1.5-7B-Chat-sft-keywords"
# model = "gpt-3.5-turbo-0125"

# togetherAI
client = OpenAI(base_url="https://api.together.xyz/v1",
                api_key="fd9f9beaff9a2516ce646d3c71ec3a20341373c35d221c8baf048abd0d796243")
# xinference
# client = OpenAI(base_url="http://localhost:9997/v1",
#                 api_key="cannot be empty")
# OpenAI
# client = OpenAI(base_url="https://api.keya.pw/v1",
#                 api_key="sk-Blb8T45CeXxlb29L347eFc8d6f2d4788B5E3212eD09d20F6")

csv_file = "../datasets/result/number/response/test_set_withgenres_{}_{}_1k.csv".format(model.replace("/", ""), random_state)
train_df = pd.read_csv(f"../datasets/llm_pre/train_set_{random_state}_1k.csv", sep=",", low_memory=False)
train_df = train_df[["userId", "movieId", "rating", "title"]]
test_df = pd.read_csv(f"../datasets/llm_pre/test_set_{random_state}_1k.csv", sep=",")
test_df = test_df[["userId", "movieId", "rating", "title"]]
genres_df = pd.read_csv("../datasets/llm_pre/out_genres_list.csv", sep=",", low_memory=False)
genres_df = genres_df[["movieId", "genres"]]
train_df["movieId"] = train_df["movieId"].astype(str)
test_df["movieId"] = test_df["movieId"].astype(str)
genres_df["movieId"] = genres_df["movieId"].astype(str)

train_df = pd.merge(train_df, genres_df, left_on='movieId', right_on='movieId', how='left')
test_df = pd.merge(test_df, genres_df, left_on='movieId', right_on='movieId', how='left')

# system_prompt = """Based on the user's past rating history and movie's keywords
# You're required to predict user ratings for the candidate movie.
# The rating ranges from 0 to 5 with increments of 0.5 allowed.
# Please provide the response in the form of a JSON list WITHOUT saying anything else.
# Results should be in the format WITHOUT saying anything else:
# [{{"title":"xxx","rating":3.0,"reason":"Telling your reason for predicting rating"}}]"""
system_prompt = """Based on the user's past rating history and movie's genres
You're required to predict user ratings for the candidate movie.
The rating ranges from 0 to 5 with increments of 0.5 allowed.
Please provide a single NUMBER as rating WITHOUT saying anything else. Do not give reasoning."""

movie_template = "{title}({genres}):{rating}"
example_prompt = PromptTemplate(
    input_variables=["title", "rating", "genres"],
    template=movie_template,
)
prefix = "The user history are:"
train_prompt = []
response_list = []


def neo4j_context_json_trun(row: str):
    neo4j_context_json = json.loads(row)
    if 'HAS_GENRE' in neo4j_context_json:
        genre_list = [item['genre'] for item in neo4j_context_json['HAS_GENRE']]
        neo4j_context_json['HAS_GENRE'] = genre_list
    if 'HAS_KEYWORD' in neo4j_context_json:
        keyword_list = [item['keyword'] for item in neo4j_context_json['HAS_KEYWORD']]
        neo4j_context_json['HAS_KEYWORD'] = keyword_list
    if 'original_language' in neo4j_context_json:
        original_language_list = [item['original_language'] for item in neo4j_context_json['original_language']]
        neo4j_context_json['original_language'] = original_language_list
    if 'PRODUCTED_IN' in neo4j_context_json:
        producted_in_list = [item['name'] for item in neo4j_context_json['PRODUCTED_IN']]
        neo4j_context_json['PRODUCTED_IN'] = producted_in_list
    if 'ACTED_IN' in neo4j_context_json:
        acted_in_list = [item['name'] for item in neo4j_context_json['ACTED_IN']]
        neo4j_context_json['ACTED_IN'] = acted_in_list
    if 'product_countries' in neo4j_context_json:
        product_countries_list = [item['name'] for item in neo4j_context_json['product_countries']]
        neo4j_context_json['product_countries'] = product_countries_list
    del neo4j_context_json["Movie"]["overview"]
    del neo4j_context_json["Movie"]["popularity"]
    del neo4j_context_json["Movie"]["vote_average"]
    # del neo4j_context_json["Movie"]["revenue"]
    neo4j_context_json = json.dumps(neo4j_context_json).replace("{", "{{").replace("}", "}}")
    return neo4j_context_json


i = 0
for userId in train_df["userId"].unique():
    i += 1
    # if userId != 141:
    #     continue
    user_df = train_df[train_df["userId"] == userId]
    user_records = user_df[["title", "rating", "genres"]].to_dict(orient='records')
    user_test_df = test_df[test_df["userId"] == userId]
    test_records = user_test_df[["title", "movieId", "rating", "genres"]].to_dict(orient='records')
    test_movieId = test_records[0]["movieId"]

    pre_example_prompt = FewShotPromptTemplate(
        examples=user_records,
        example_prompt=example_prompt,
        example_separator="\n",
        prefix=prefix,
        # suffix="The candidate movie are ({movie}).\nAnd here's' movie's metadata from neo4j:\n"
        #        "{movie_context}\n"
        suffix="\n\nThe candidate movie is {movie}({genres})",
        input_variables=["movie", "genres"],
    )

    # print(pre_example_prompt)
    # print(test_records[0]["neo4j_context"])
    full_prompt = pre_example_prompt.format(
        movie=test_records[0]["title"],
        genres=test_records[0]["genres"],
    )
    # print(neo4j_context_json)
    print(full_prompt)
    try:
        completion = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": system_prompt,
                },
                {
                    "role": "user",
                    "content": full_prompt,
                },
            ],
            temperature=0.2,
            # top_p=0.3,
            # presence_penalty=0,
        )
        # print(full_prompt)
        response = completion.choices[0].message.content
        row = {"userId": userId, "movieId": test_movieId, "response": str(response)}
        print(response)
    except:
        # response_list.append({"UserId": userId, "movieId": test_movieId, "response": "NULL"})
        row = [{"UserId": userId, "movieId": test_movieId, "response": "NULL"}]
    print(userId)
    row_df = pd.DataFrame(row, index=[i])
    # print(row_df)
    with open(csv_file, 'a', encoding="utf-8") as f:
        row_df.to_csv(f, header=f.tell() == 0, index=False, mode='a')
    # print(response_list)
    # time.sleep(0.5)

# response_df = pd.DataFrame(response_list)
# response_df.to_csv(csv_file, index=False)
