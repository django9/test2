import pandas as pd
import json
import re


def tmdb_datasets_pre():
    # 正则表达式，用于匹配字母数字字符串
    pattern = re.compile("[A-Za-z0-9]+")

    # genres 类型
    out_genres = open("../datasets/neo4j_pre/out_genres.csv", "w", encoding='utf-8')
    out_genres.write("id,genres\n")

    # original_language
    out_original_language = open("../datasets/neo4j_pre/out_original_language.csv", "w", encoding='utf-8')
    out_original_language.write("id,original_language\n")

    # title
    out_title = open("../datasets/neo4j_pre/out_title.csv", "w", encoding='utf-8')
    out_title.write("id,title\n")

    # overview
    out_overview = open("../datasets/neo4j_pre/out_overview.csv", "w", encoding='utf-8')
    out_overview.write("id,overview\n")

    # popularity
    out_popularity = open("../datasets/neo4j_pre/out_popularity.csv", "w", encoding='utf-8')
    out_popularity.write("id,original_popularity\n")

    # production_companies
    out_production_companies = open("../datasets/neo4j_pre/out_production_companies.csv", "w", encoding='utf-8')
    out_production_companies.write("id;production_companies\n")

    # production_countries
    out_production_countries = open("../datasets/neo4j_pre/out_production_countries.csv", "w", encoding='utf-8')
    out_production_countries.write("id;production_countries\n")

    # release_date
    out_release_date = open("../datasets/neo4j_pre/out_release_date.csv", "w", encoding='utf-8')
    out_release_date.write("id;release_date\n")

    # revenue 票房收入
    out_revenue = open("../datasets/neo4j_pre/out_revenue.csv", "w", encoding='utf-8')
    out_revenue.write("id;revenue\n")

    # vote_average
    out_vote_average = open("../datasets/neo4j_pre/out_vote_average.csv", "w", encoding='utf-8')
    out_vote_average.write("id;vote_average\n")

    # vote_count
    out_vote_count = open("../datasets/neo4j_pre/out_vote_count.csv", "w", encoding='utf-8')
    out_vote_count.write("id;vote_count\n")

    # movies_metadata 元数据载入
    df = pd.read_csv("../datasets/raw/movies_metadata.csv", sep=",", low_memory=False)
    # 筛选json字段列
    json_columns = ['genres', "production_companies", "production_countries"]
    for column in json_columns:
        # str载入 json.loads
        df[column] = df[column].apply(lambda x: json.loads(json.dumps(eval(x))) if pd.notnull(x) else x)
    # 普通列（非json列）
    df = df[["id", "genres", "original_language", "title", "overview", "popularity",
             'production_companies', "production_countries", "release_date", "revenue", "vote_average", "vote_count"]]

    # 逐条处理DataFrame
    for _, row in df.iterrows():
        id = row["id"]

        # 剔除不符合"字母数字字符串"的 'id' 行
        if not pattern.fullmatch(id):
            continue

        # genres
        for g in row["genres"]:
            genres = g["name"]
            genres = "\"" + genres + "\""
            out_genres.write(f"{id},{genres}\n")

        # original_language
        original_language = row["original_language"]
        original_language = "\"" + str(original_language) + "\""
        out_original_language.write(f"{id},{original_language}\n")

        # original_title
        original_title = str(row["title"])
        original_title = "\"" + original_title.replace("\"", "") + "\""
        out_title.write(f"{id},{original_title}\n")

        # overview
        overview = row["overview"]
        overview = "\"" + str(overview).replace("\"", "") + "\""
        out_overview.write(f"{id},{overview}\n")

        # popularity
        popularity = row["popularity"]
        out_popularity.write(f"{id},{popularity}\n")

        # production_companies
        if isinstance(row["production_companies"], list):
            for g in row["production_companies"]:
                if "name" in g and isinstance(g["name"], str):
                    production_companies = g["name"]
                    out_production_companies.write(f"{id};{production_companies}\n")

        # production_countries
        if isinstance(row["production_countries"], list):
            for g in row["production_countries"]:
                if "name" in g and isinstance(g["name"], str):
                    production_countries = g["name"]
                    out_production_countries.write(f"{id};{production_countries}\n")

        # release_date
        release_date = row["release_date"]
        release_date = "\"" + str(release_date) + "\""
        out_release_date.write(f"{id};{release_date}\n")

        # revenue
        revenue = row["revenue"]
        out_revenue.write(f"{id};{revenue}\n")

        # vote_average
        vote_average = row["vote_average"]
        out_vote_average.write(f"{id};{vote_average}\n")

        # vote_count
        vote_count = row["vote_count"]
        out_vote_count.write(f"{id};{vote_count}\n")


if __name__ == "__main__":
    tmdb_datasets_pre()
