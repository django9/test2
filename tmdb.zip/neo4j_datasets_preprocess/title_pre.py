import pandas as pd
from tools.database import Neo4jDatabase
import re


def tmdb_datasets_pre():
    # 生成 out_ratings_title.csv
    # 生成 userId, movieId 所对应的 电影title

    # ratings_df metadata_df 载入
    ratings_df = pd.read_csv("../datasets/raw/ratings.csv", sep=",", low_memory=False)
    metadata_df = pd.read_csv("../datasets/raw/movies_metadata.csv", sep=",", low_memory=False)

    ratings_df = ratings_df[["userId", "movieId", "rating", "timestamp"]]
    ratings_df['movieId'] = ratings_df['movieId'].astype(str)  # 仅输出str
    metadata_df = metadata_df[["id", "title"]]

    # 每位用户的评分数量
    user_movie_counts = ratings_df.groupby("userId")["movieId"].nunique()
    # 筛选至少评价过10部电影的用户
    active_users = user_movie_counts[user_movie_counts >= 10].index.tolist()
    # 过滤出活跃用户的评分记录
    ratings_df = ratings_df[ratings_df["userId"].isin(active_users)]

    # dataframe left join 合并标题
    merged_df = pd.merge(ratings_df, metadata_df, left_on='movieId', right_on='id', how='left')
    merged_df = merged_df.dropna(subset=['title'], how='any')

    # 写入out_ratings_title.csv
    merged_df.to_csv("../datasets/llm_pre/out_ratings_title.csv", index=False)


def neo4j_to_json(movieId: str, database: Neo4jDatabase):
    # Cypher语句
    # 从neo4j知识图谱 请求 movieId电影的所有数据
    cypher_statement = f"""
                MATCH (m:Movie {{id: {movieId}}})
                WITH m
                OPTIONAL MATCH p=(n)-[r]-(m)
                WITH m, COLLECT({{Node: n, Relationship: r}}) AS relationship
                RETURN {{
                  Movie: m,
                  Relationship: relationship
                }} AS Result
                """
    neo4j_context = database.query(cypher_statement, "Movie")
    return f"{neo4j_context}"


def tmdb_neo4j_pre():
    # neo4j 数据库配置
    database = Neo4jDatabase(host="bolt://127.0.0.1:7687",
                             user="neo4j", password="password")

    # movies_metadata载入
    metadata_df = pd.read_csv("../datasets/raw/movies_metadata.csv", sep=",", low_memory=False)
    metadata_df = metadata_df[["id", "title"]]


    pattern = re.compile("[0-9]+")
    data = []
    for i, row in metadata_df.iterrows():
        movieId = row["id"]
        if not pattern.fullmatch(movieId):
            continue
        title = row["title"]
        neo4j_context = neo4j_to_json(movieId, database)
        data.append({"movieId": movieId,
                     "title": title,
                     "neo4j_context": neo4j_context,
                     })
        print(i)

    # dataframe 导出 csv
    out_id_neo4j_merge = pd.DataFrame(data)
    out_id_neo4j_merge.to_csv("../datasets/llm_pre/id_neo4j_merge.csv", index=False)

if __name__ == "__main__":
    # tmdb_datasets_pre()
    tmdb_neo4j_pre()
