import pandas as pd
import json
import re


def tmdb_datasets_pre():
    # 正则表达式，用于匹配字母数字字符串
    pattern = re.compile("[A-Za-z0-9]+")

    # out_keywords
    out_keywords = open("../datasets/neo4j_pre/out_keywords.csv", "w", encoding='utf-8')
    out_keywords.write("id,keywords\n")

    df = pd.read_csv("../datasets/raw/keywords.csv", sep=",", low_memory=False)

    # 处理 'keywords' JSON 列
    json_columns = ['keywords']
    for column in json_columns:
        df[column] = df[column].apply(lambda x: json.loads(json.dumps(eval(x))) if pd.notnull(x) else x)

    # 普通列（非json列）
    df = df[["id", "keywords"]]

    # 逐条处理DataFrame
    for _, row in df.iterrows():
        id = row["id"]
        # 剔除不符合"字母数字字符串"的 'id' 行
        if not pattern.fullmatch(str(id)):
            continue

        # keywords
        if isinstance(row["keywords"], list):
            for g in row["keywords"]:
                if "name" in g and isinstance(g["name"], str):
                    keywords = g["name"]
                    out_keywords.write(f"{id},{keywords}\n")


if __name__ == "__main__":
    tmdb_datasets_pre()
