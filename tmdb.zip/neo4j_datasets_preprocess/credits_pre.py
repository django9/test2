import pandas as pd
import json
import re

def tmdb_datasets_pre():
    # 正则表达式，用于匹配字母数字字符串
    pattern = re.compile("[A-Za-z0-9]+")
    
    # out_cast 创建
    out_cast = open("../datasets/neo4j_pre/out_cast.csv", "w", encoding='utf-8')
    out_cast.write("id,cast,character\n")

    # out_crew 创建
    out_crew = open("../datasets/neo4j_pre/out_crew.csv", "w", encoding='utf-8')
    out_crew.write("id,crew,job\n")

    # credits 载入
    df = pd.read_csv("../datasets/raw/credits.csv", sep=",", low_memory=False)
    json_columns = ['cast', 'crew']
    
    # 处理 'cast' 和 'crew' JSON 列
    for column in json_columns:
        # 将str转换为dict/list
        df[column] = df[column].apply(lambda x: json.loads(json.dumps(eval(x))) if pd.notnull(x) else x)
    
    # 筛选cast, crew列
    df = df[["id", "cast", "crew"]]

    # 逐条处理DataFrame
    for _, row in df.iterrows():
        id = row["id"]
        
        # 剔除不符合"字母数字字符串"的 'id' 行
        if not pattern.fullmatch(str(id)):
            continue

        # 处理cast信息
        if isinstance(row["cast"], list):
            for cast in row["cast"]:
                if "name" in cast and isinstance(cast["name"], str):
                    # 筛选顺序前六的演员
                    if cast['order'] < 6:
                        cast_name = cast["name"].replace("\"", "\\\"")
                        cast_character = cast["character"].replace("\"", "\\\"")
                        # 将cast数据写入文件
                        out_cast.write(f"{id},{cast_name},{cast_character}\n")

        # 处理crew信息
        if isinstance(row["crew"], list):
            for crew in row["crew"]:
                if "name" in crew and isinstance(crew["name"], str):
                    crew_job = crew["job"].replace("\"", "\\\"")
                    # 筛选重要crew：'Director', 'Producer', 'Writer'
                    if crew_job in ['Director', 'Producer', 'Writer']:
                        crew_name = crew["name"].replace("\"", "\\\"")
                        # 写入文件
                        out_crew.write(f"{id},{crew_name},{crew_job}\n")


if __name__ == "__main__":
    tmdb_datasets_pre()
